/* app.js — full, robust game logic and UI glue */
(() => {
  // --- helpers
  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));
  const el = id => document.getElementById(id);

  // UI elements
  const boardEl = el('board');
  const turnEl = el('turn');
  const resultEl = el('result'); 
  const movesEl = el('moves');
  const scoreX = el('scoreX'), scoreO = el('scoreO'), scoreT = el('scoreT');
  const timerXEl = el('timerX'), timerOEl = el('timerO');

  const themeBtn = el('themeBtn'), modeHuman = el('modeHuman'), modeAI = el('modeAI');
  const difficultySel = el('difficulty'), undoBtn = el('undoBtn'), restartBtn = el('restartBtn'), resetSeries = el('resetSeries');

  // Game state
  let board = Array(9).fill(null); // 'X'|'O'|null
  let current = 'X';
  let running = true;
  let mode = 'human'; // 'human' | 'ai'
  let difficulty = 'medium';
  let history = []; // snapshots after each move: { board, move, player }
  let movesList = []; // readable moves {i,player}
  let scores = { X: 0, O: 0, T: 0 };
  let timers = { X: 0, O: 0 }, timerInterval = null;
  let focused = 0;

  // audio (safe)
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  const audio = (typeof AudioCtx !== 'undefined') ? new AudioCtx() : null;
  function tone(freq=440,dur=0.08,type='sine',vol=0.06){
    if(!audio) return;
    try{
      const o = audio.createOscillator(), g = audio.createGain();
      o.type = type; o.frequency.value = freq; g.gain.value = vol;
      o.connect(g); g.connect(audio.destination);
      o.start();
      setTimeout(()=>{ try{ o.stop(); }catch(e){} }, dur*1000);
    }catch(e){}
  }
  const sfx = {
    place(){ tone(520, .05, 'sine', .06); },
    win(){ tone(620,.1,'triangle',.11); setTimeout(()=>tone(740,.12,'triangle',.09),110); setTimeout(()=>tone(880,.14,'triangle',.08),220); },
    tie(){ tone(300,.08,'sawtooth',.05); setTimeout(()=>tone(220,.1,'sawtooth',.04),100); }
  };

  // confetti
  const confCanvas = document.getElementById('confetti');
  const cctx = confCanvas.getContext && confCanvas.getContext('2d');
  let confettiParts = [];
  function resizeConf(){ if(!confCanvas) return; confCanvas.width = innerWidth; confCanvas.height = innerHeight; }
  window.addEventListener('resize', resizeConf);
  resizeConf();
  function confettiBurst(n=80){
    if(!cctx) return;
    const colors = ['#4cc9f0','#72efdd','#ff7b7b','#ffd166','#bdb2ff'];
    for(let i=0;i<n;i++){
      confettiParts.push({
        x: innerWidth/2 + (Math.random()-0.5)*200,
        y: innerHeight/3 + (Math.random()-0.5)*80,
        vx: (Math.random()-0.5)*8,
        vy: Math.random()*-6-3,
        r: 3 + Math.random()*4,
        c: colors[(Math.random()*colors.length)|0],
        a:1, rot: Math.random()*Math.PI*2, dr: (Math.random()-0.5)*0.2
      });
    }
    if(confettiParts.length) requestAnimationFrame(confLoop);
  }
  function confLoop(){
    if(!cctx) return;
    cctx.clearRect(0,0,confCanvas.width, confCanvas.height);
    for(let p of confettiParts){
      p.vy += 0.12; p.x += p.vx; p.y += p.vy; p.rot += p.dr; p.a -= 0.006;
      cctx.save(); cctx.globalAlpha = Math.max(p.a,0);
      cctx.translate(p.x, p.y); cctx.rotate(p.rot);
      cctx.fillStyle = p.c; cctx.fillRect(-p.r, -p.r, p.r*2, p.r*2);
      cctx.restore();
    }
    for(let i=confettiParts.length-1;i>=0;i--) if(confettiParts[i].a<=0 || confettiParts[i].y>innerHeight+20) confettiParts.splice(i,1);
    if(confettiParts.length) requestAnimationFrame(confLoop);
  }

  // winlines
  const winLines = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6]
  ];

  function checkWinner(b){
    for(const [a,b1,c] of winLines){
      if(b[a] && b[a] === b[b1] && b[a] === b[c]) return { winner: b[a], line: [a,b1,c] };
    }
    if(b.every(x=>x)) return { tie:true };
    return null;
  }

  // build board UI
  function buildBoard(){
    boardEl.innerHTML = '';
    for(let i=0;i<9;i++){
      const c = document.createElement('button');
      c.className = 'cell';
      c.setAttribute('data-i', i);
      c.setAttribute('aria-label', 'cell ' + (i+1));
      c.tabIndex = 0;
      c.addEventListener('click', () => onCellClick(i));
      c.addEventListener('keydown', e => {
        if(e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onCellClick(i); }
      });
      boardEl.appendChild(c);
    }
    updateBoard();
  }

  function updateBoard() {
    board.forEach((v,i)=>{
      const node = boardEl.querySelector(`.cell[data-i="${i}"]`);
      if(!node) return;
      node.innerHTML = v ? `<span class="marker ${v==='X'?'x':'o'}">${v}</span>` : '';
      node.classList.toggle('disabled', !running || v !== null);
    });
  }

  // history UI update
  function updateHistoryUI(){
    movesEl.innerHTML = '';
    movesList.forEach((m, idx) => {
      const li = document.createElement('li');
      li.textContent = `${idx+1}. ${m.player} → ${m.i+1}`;
      const btn = document.createElement('button');
      btn.textContent = '↩';
      btn.className = 'btn';
      btn.style.marginLeft = '8px';
      btn.addEventListener('click', ()=> revertTo(idx));
      li.appendChild(btn);
      movesEl.appendChild(li);
    });
  }

  // make move (push history AFTER move to keep snapshots accurate)
  function makeMove(i, player, pushHistory=true){
    if(!running || board[i]) return false;
    board[i] = player;
    if(pushHistory) history.push({ board: board.slice(), move: i, player: player });
    movesList.push({i,player});
    updateHistoryUI();
    updateBoard();
    sfx.place();

    const res = checkWinner(board);
    if(res){
      running = false;
      if(res.winner){
        highlightWin(res.line);
        resultEl.textContent = `${res.winner} wins!`;
        scores[res.winner]++;
        updateScores();
        sfx.win();
        confettiBurst();
      } else {
        resultEl.textContent = `Tie!`;
        scores.T++;
        updateScores();
        sfx.tie();
      }
      stopTimers();
    } else {
      current = (player === 'X') ? 'O' : 'X';
      turnEl.textContent = current;
      // if AI and it's AI's turn, schedule AI play
      if(mode === 'ai' && current === 'O') {
        setTimeout(()=> aiMove(), 220 + Math.random()*200);
      }
    }
    return true;
  }

  function highlightWin(line){
    for(const idx of line){
      const node = boardEl.querySelector(`.cell[data-i="${idx}"]`);
      if(node) node.classList.add('win');
    }
  }

  // undo: remove last move
  function undo(){
    if(history.length === 0) return;
    // remove last snapshot
    history.pop();
    movesList.pop();
    if(history.length > 0) board = history[history.length-1].board.slice();
    else board = Array(9).fill(null);
    running = true;
    current = board.some(x=>x) ? (history[history.length-1].player === 'X' ? 'O' : 'X') : 'X';
    turnEl.textContent = current;
    resultEl.textContent = 'Game resumed';
    $$('.cell.win').forEach(n=>n.classList.remove('win'));
    updateBoard();
    updateHistoryUI();
    startTimers();
  }

  // new game
  function newGame(resetSeriesFlag=false){
    board = Array(9).fill(null);
    current = 'X';
    running = true;
    history = [];
    movesList = [];
    resultEl.textContent = 'Game on…';
    $$('.cell.win').forEach(n=>n.classList.remove('win'));
    updateBoard();
    updateHistoryUI();
    if(resetSeriesFlag){
      scores = {X:0,O:0,T:0}; updateScores();
    }
    startTimers(true);
    // if vs AI and it's O's turn, handle if needed
    if(mode === 'ai' && current === 'O') setTimeout(()=>aiMove(), 300);
  }

  // revert to move index
  function revertTo(idx){
    if(idx < 0){ board = Array(9).fill(null); history = []; movesList = []; running = true; current = 'X'; }
    else {
      const snapshot = history[idx];
      board = snapshot.board.slice();
      history = history.slice(0, idx+1);
      movesList = movesList.slice(0, idx+1);
      current = (history.length && history[history.length-1].player === 'X') ? 'O' : 'X';
    }
    $$('.cell.win').forEach(n=>n.classList.remove('win'));
    updateBoard(); updateHistoryUI(); resultEl.textContent='Reverted';
    startTimers();
  }

  function updateScores(){
    scoreX.textContent = scores.X;
    scoreO.textContent = scores.O;
    scoreT.textContent = scores.T;
  }

  // timers
  function startTimers(reset=false){
    clearInterval(timerInterval);
    if(reset){ timers = {X:0,O:0}; timerXEl.textContent='X: 00:00'; timerOEl.textContent='O: 00:00'; }
    timerInterval = setInterval(()=>{
      timers[current] += 1;
      timerXEl.textContent = `X: ${formatTime(timers.X)}`;
      timerOEl.textContent = `O: ${formatTime(timers.O)}`;
    }, 1000);
  }
  function stopTimers(){ clearInterval(timerInterval); timerInterval = null; }
  function formatTime(s){
    const mm = Math.floor(s/60).toString().padStart(2,'0');
    const ss = (s%60).toString().padStart(2,'0');
    return `${mm}:${ss}`;
  }

  // AI moves
  function aiMove(){
    if(!running) return;
    let move;
    if(difficulty === 'easy') move = randomMove();
    else if(difficulty === 'medium') {
      if(Math.random() < 0.6) move = bestMove(board, 'O', 4); else move = randomMove();
    } else move = bestMove(board, 'O', 9);
    if(move !== null) makeMove(move, 'O');
  }

  function randomMove(){
    const empties = board.map((v,i)=>v?null:i).filter(v=>v!==null);
    if(!empties.length) return null;
    return empties[(Math.random()*empties.length)|0];
  }

  // minimax (depth limit)
  function bestMove(b, player, maxDepth=9){
    const opponent = player === 'X' ? 'O' : 'X';
    // immediate win
    for(let i=0;i<9;i++) if(!b[i]){
      b[i] = player;
      if(checkWinner(b)?.winner === player){ b[i] = null; return i; }
      b[i] = null;
    }
    // block opponent immediate win
    for(let i=0;i<9;i++) if(!b[i]){
      b[i] = opponent;
      if(checkWinner(b)?.winner === opponent){ b[i] = null; return i; }
      b[i] = null;
    }

    function minimax(boardState, depth, isMax){
      const res = checkWinner(boardState);
      if(res){
        if(res.winner === player) return 10 - depth;
        if(res.winner === opponent) return depth - 10;
        if(res.tie) return 0;
      }
      if(depth >= maxDepth) return 0;
      let best = isMax ? -Infinity : Infinity;
      for(let i=0;i<9;i++){
        if(!boardState[i]){
          boardState[i] = isMax ? player : opponent;
          const val = minimax(boardState, depth+1, !isMax);
          boardState[i] = null;
          if(isMax) best = Math.max(best, val); else best = Math.min(best, val);
        }
      }
      if(best === -Infinity || best === Infinity) return 0;
      return best;
    }

    let bestVal = -Infinity, bestIdx = null;
    for(let i=0;i<9;i++){
      if(!b[i]){
        b[i] = player;
        const score = minimax(b, 0, false);
        b[i] = null;
        if(score > bestVal){ bestVal = score; bestIdx = i; }
      }
    }
    if(bestIdx === null) return randomMove();
    return bestIdx;
  }

  // UI event handlers
  function onCellClick(i){
    if(!running || board[i]) return;
    if(mode === 'ai' && current === 'O') return;
    makeMove(i, current, true);
  }

  // keyboard navigation & shortcuts
  document.addEventListener('keydown', (e) => {
    if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)){
      e.preventDefault();
      const row = Math.floor(focused/3), col = focused%3;
      if(e.key === 'ArrowUp') { if(row > 0) focused -=3; }
      if(e.key === 'ArrowDown') { if(row < 2) focused +=3; }
      if(e.key === 'ArrowLeft') { if(col > 0) focused -=1; }
      if(e.key === 'ArrowRight') { if(col < 2) focused +=1; }
      focused = Math.max(0, Math.min(8, focused));
      const node = boardEl.querySelector(`.cell[data-i="${focused}"]`);
      if(node) node.focus();
    }
    if(e.key === 'Enter' || e.key === ' ') {
      const node = boardEl.querySelector(`.cell[data-i="${focused}"]`);
      if(node) { e.preventDefault(); node.click(); }
    }
    if(e.key.toLowerCase() === 'r'){ e.preventDefault(); newGame(); }
    if(e.key.toLowerCase() === 't'){ e.preventDefault(); toggleTheme(); }
    if((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z'){ e.preventDefault(); undo(); }
  });

  // control wiring
  themeBtn.addEventListener('click', toggleTheme);
  modeHuman.addEventListener('click', ()=> setMode('human'));
  modeAI.addEventListener('click', ()=> setMode('ai'));
  difficultySel.addEventListener('change', e => difficulty = e.target.value);
  undoBtn.addEventListener('click', undo);
  restartBtn.addEventListener('click', ()=> newGame(false));
  resetSeries.addEventListener('click', ()=> newGame(true));

  function setMode(m){
    mode = m;
    modeHuman.setAttribute('aria-pressed', mode==='human');
    modeAI.setAttribute('aria-pressed', mode==='ai');
    resultEl.textContent = (mode==='ai') ? 'Playing vs AI' : 'PvP mode';
    if(mode==='ai' && current==='O') setTimeout(()=>aiMove(), 250);
  }

  // theme toggling
  let light = false;
  function toggleTheme(){
    light = !light;
    if(light) document.documentElement.classList.add('light'); else document.documentElement.classList.remove('light');
    themeBtn.setAttribute('aria-pressed', light+'');
  }

  // init
  function init(){
    buildBoard();
    updateBoard();
    updateScores();
    startTimers(true);
    setMode('human');
    // focus first cell
    const first = boardEl.querySelector('.cell[data-i="0"]');
    if(first) { first.focus(); focused = 0; }
  }

  // expose for debugging
  window.ttt = { makeMove, newGame, undo, setMode, aiMove, bestMove };

  init();
})();
// ================= THEME TOGGLE =================
document.addEventListener("DOMContentLoaded", () => {
  const themeBtn = document.getElementById("themeBtn");

  if (!themeBtn) {
    console.error("❌ Theme button not found!");
    return;
  }

  // Apply saved theme if any
  if (localStorage.getItem("theme") === "light") {
    document.body.classList.add("light");
    themeBtn.textContent = "🌞 Light Mode";
    themeBtn.setAttribute("aria-pressed", "true");
  }

  themeBtn.addEventListener("click", () => {
    const isLight = document.body.classList.toggle("light");
    themeBtn.textContent = isLight ? "🌞 Light Mode" : "🌗 Dark Mode";
    themeBtn.setAttribute("aria-pressed", isLight);
    localStorage.setItem("theme", isLight ? "light" : "dark");
  });
});
